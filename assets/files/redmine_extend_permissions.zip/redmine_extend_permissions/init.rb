require 'redmine'

Redmine::Plugin.register :redmine_extend_permissions do
  name 'Redmine Extend Permissions plugin'
  author 'Aaron Addleman'
  description 'This is a plugin for Redmine to add additional permissions to views or controllers by over writing the view with code in redmine_extend_permissions/app/views/*'
  version '0.0.2'
  url 'http://9thport.net/2011/03/20/redmine-hide-assigned-to-field-with-role-permissions-plugin/'
  author_url 'http://9thport.net/about/'

  permission :view_assigned_to, :issues => :index
end

