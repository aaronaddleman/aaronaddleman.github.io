require 'redmine'
require 'date'

# require 'redmine_due_date_offset/redmine_due_date_offset'
require 'redmine_due_date_offset/hooks/model_issue_hook'

Redmine::Plugin.register :redmine_due_date_offset do
  name 'Redmine Due Date Offset plugin'
  author 'Aaron Addleman'
  description 'This is a plugin for Redmine to set the due date of a issue.'
  version '0.0.2'
  url 'http://www.aaronaddleman.com/articles/redmine_due_date_offset'
  author_url 'http://example.com/about'
end