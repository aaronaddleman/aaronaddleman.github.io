module RedmineIssueDueDate
  module Hooks
    class ModelIssueHook < Redmine::Hook::ViewListener
      def next_weekday(original_date, step=1)
        result = original_date
        counter = 0

        until counter == step
          result += 1.day
          counter += 1

          # skip saturday
          if result.saturday?
            result += 1.day
          end

          # skip sunday
          if result.sunday?
            result += 1.day
          end
        end

        result
      end

      def controller_issues_edit_before_save(context={})
        params = context[:params]
        if context[:issue].due_date.nil? || (params[:issue][:due_date] == '')
          update_due_date(context, false)
          context[:issue].save
        end
      end

      def controller_issues_new_before_save(context={})
        params = context[:params]
        if context[:issue].due_date.nil? || (params[:issue][:due_date] == '')
          update_due_date(context, false)
          context[:issue].save
        end
      end
      
      def update_due_date(context, create_journal)
        params = context[:params]

        if params && params[:issue]
          year, month, day = params[:issue][:start_date].split("-")
          context[:issue].due_date = next_weekday(Time.new(year,month,day,00,00,00,"-08:00"), 3).strftime("%Y-%m-%d").to_s
        end
      end

    end
  end
end
